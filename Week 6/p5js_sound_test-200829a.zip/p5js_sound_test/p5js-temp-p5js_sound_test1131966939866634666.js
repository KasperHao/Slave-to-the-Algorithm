//280820 P5js Sound test
var song; // here we give a name to our song variable
var analyzer;
let dim;
function preload(){
song = loadSound('data/teaser1.mp3');// here we link the song variable
}
function setup() {
  
createCanvas(windowWidth,windowHeight);
ellipseMode(RADIUS);
background(0);//background of canvas
fill(0,255,0); //colour of our object
song.loop;
//set analyzer to check amplitude
analyzer= new p5.Amplitude();
analyzer.setInput(song);
noStroke;
}


function draw() {
background(0,1);
var volume=analyzer.getLevel();//this will extracr the volume of the song we habe sent to the analyzer
volume=(volume*windowWidth)+60;
ellipse(windowWidth/2,windowHeight/2,volume,volume);//object drawn to screen
for (let x = 0; x <= width; x += dim) {
    drawGradient(x, height / 2);
    }
}

function drawGradient(x, y) {
  let radius = dim / 2;
  let h = random(0, 360);
  for (let r = radius; r > 0; --r) {
    fill(h, 90, 90);
    ellipse(x, y, r, r);
    h = (h + 1) % 360;
  }
}
function mousePressed(){//triggers on mousepress
  if(song.isPlaying()){//check if the song is playing
    song.stop();//if it is, then stop the song
    song.noLoop();
    fill(0,255,0);
  } 
  else{ fill(0,0,255);// changes fill to blue
    song.play(); //if it isn't then play the song
    song.loop();
  }
}
