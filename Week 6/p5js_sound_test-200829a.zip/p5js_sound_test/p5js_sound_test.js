//280820 P5js Sound test
var song; // here we give a name to our song variable
var analyzer;
function preload(){
song = loadSound('data/teaser1.mp3');// here we link the song variable
}
function setup() {
  
createCanvas(windowWidth,windowHeight);
background(0);//background of canvas
fill(0,255,0); //colour of our object
song.loop;
//set analyzer to check amplitude
analyzer= new p5.Amplitude();
analyzer.setInput(song);
noStroke;
}


function draw() {
background(0,1);
var volume=analyzer.getLevel();//this will extracr the volume of the song we habe sent to the analyzer
volume=(volume*windowWidth)+60;
ellipse(windowWidth/2,windowHeight/2,volume,volume);//object drawn to screen
}

function mousePressed(){//triggers on mousepress
  if(song.isPlaying()){//check if the song is playing
    song.stop();//if it is, then stop the song
    song.noLoop();
    fill(0,255,0);
  } 
  else{ fill(0,0,255);// changes fill to blue
    song.play(); //if it isn't then play the song
    song.loop();
  }
}
